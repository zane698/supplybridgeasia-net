# 致大禹节水：苏尔汉河 SWP-3、阿尔巴尼亚 Fushe Kuqe 及布哈拉 RFB/11 三大项目完整标书包、资格门槛与实施支持详单

傅总、王总、闫经理、欧经理，您好：

针对贵司在微信群中重点点名的三个项目——**【乌兹别克斯坦·苏尔汉河 SWP-3 取水工程】**、**【阿尔巴尼亚·都拉斯 Fushe Kuqe 输水干管及新建泵站】**、以及**【乌兹别克斯坦·布哈拉 RFB/11 供水管网】**，我方已将前两个**可免费获取标书项目**的全套官方招标文件、工程量清单（BOQ）、资格审查标准、技术规范及最新澄清补遗全部提取完毕（原件压缩包同步通过微信发您）；第三个付费纸质标（布哈拉 RFB/11）已按贵司要求整理出官方 $150 USD 购标路径与收款账户（暂不代购或安排付费）。

三大项目的最终截止时间、资格硬门槛、最新补遗核查及我方当地配合支持详单汇总如下：

---

## 一、三大项目核心招标参数、资格硬门槛、最新补遗与最终截止时间

### 1. 乌兹别克斯坦·苏尔汉河 SWP-3 取水设施建设工程（EBRD 电子标 · 0元购标 · 适配度最高）
- **项目编号与名称**：EBRD Project ID `50979` / ECEPP ID `43048283` — *SWP-3 Construction of Water Intake Facilities*
- **业主 / 执行机构**：`Surkhandaryo Suv Taminoti JSC`（最终受益人） / `Uzsuvtaminot JSC` 旗下 EBRD PIU（主任 Mr. Asliddin Isayev，邮箱 `po.ebrd@uzsuv.uz`）
- **标段划分与核心工程量（FIDIC 黄皮书设计施工总承包 Design-Build · 可单投 1 个标段，也可两标段同投）**：
  - **Lot 1（`SWP-03 Lot 1: Construction of Pashkhurt Water Intake Facility`）**：设计供水规模 **$13,000\text{ m}^3/\text{天}$**；新建 **12 口深井**（10 用 2 备，井深 $70/80/90\text{ m}$）及深井潜水泵；新建 **2 座 $500\text{ m}^3$** 现浇钢筋混凝土清水池（B25 W8 F150）；现场电解食盐次氯酸钠发生器消毒站；**PE100 集水输水管道约 $6,750\text{ m}$**；既有观测井液位计加装；$10/0.4\text{ kV}$ 箱变、值班操作楼及 SCADA 自动化系统（重力流接入后续 SWP-04 干管标段）。
  - **Lot 2（`SWP-03 Lot 2: Construction of Sherjan Water Intake Facility`）**：设计供水规模 **$4,320\text{ m}^3/\text{天}$**；新建 **4 口深井**（3 用 1 备，井深 $90\text{ m}$）及深井潜水泵；新建 **2 座 $1,000\text{ m}^3$** 现浇钢筋混凝土清水池；现场电解次氯酸钠发生器消毒站；SWP-04 进水端 **DN400 PN40 流量与压力调节站**；**PE100 集水管道约 $1,610\text{ m}$**；$10/0.4\text{ kV}$ 箱变、操作楼及 SCADA 系统（出口接 DN800 闸阀至 SWP-05 标段）。
- **最终截止时间**：**2026 年 12 月 29 日 12:00（英国时间 UK Time / 塔什干时间 17:00 / 北京时间 20:00）**，通过 EBRD ECEPP 平台全电子化投递（按 Data Sheet `ITP 15.5`，投标保函须在系统上传原件扫描件及快递寄出底单，并将保函原件寄达业主；中标人须在收到中标通知书 28 个日历日内递交授权书及联营协议公证/海牙认证原件）。
- **最新补遗与现场踏勘（极利好）**：
  - **补遗状态**：2026 年 11 月 11 日发布正标，截至 2026 年 11 月 25 日登录 EBRD ECEPP 平台核查，Step 2 栏下**暂未发布新增补遗（Amendments/Clarifications）**；澄清提问截止为截标前 14 个日历日（**2026 年 12 月 15 日**，须通过 ECEPP Message Centre 提交）。
  - **现场踏勘（Data Sheet ITP 9.6）**：**非强制（Attendance at the Site visit is NOT mandatory）**，标书明文规定不参加现场踏勘不构成拒绝投标的理由（*Non-attendance at the Site visit shall not be a cause for rejection of a Participant's proposal*）；标前澄清会采用线上视频会议形式。
- **⚠️ 标书原件中 4 大项（共 7 处）“英文大写与阿拉伯数字不一致”提示**（疑为业主编辑笔误，**建议统一按较高值准备，并在 12 月 15 日前通过 ECEPP Message Centre 向业主发澄清确认**）：
  1. **投标保证金（Data Sheet ITP 15.3，含 2 处不一致）**：
     - **Lot 1**：原文为 `USD 30,000 (fifty thousand United States Dollars)`［数字 3 万 / 大写 5 万美元］；
     - **Lot 2**：原文为 `USD 15,000 (twenty-five thousand United States Dollars)`［数字 1.5 万 / 大写 2.5 万美元］；
     - **保函银行要求（ITP 15.4）**：须由信用评级不低于 `B-`（S&P 或 Fitch）的银行或乌兹别克斯坦境内银行出具见索即付银行保函（两标段同投须分别开立保函）。
  2. **近 3 年（2023–2025）年均营业收入（Section IV Table 2.2，含 1 处不一致）**：
     - **Lot 1**：$\ge \text{USD } 2,700,000$（大写与数字一致，270 万美元）；
     - **Lot 2**：$\ge \text{USD } 1,800,000$（大写与数字一致，180 万美元）；
     - **两标段同投**：原文为 `three million four hundred thousand United States Dollars (USD 4,500,000)`［大写 340 万 / 数字 450 万美元］；联营体（JVCA）牵头方须满足 $\ge 50\%$，其他每方成员须满足 $\ge 30\%$。
  3. **4 个月可用流动资金/银行授信（Section IV Table 2.4，含 2 处不一致）**：
     - **Lot 1**：原文为 `six hundred thousand United States Dollars (USD 700,000)`［大写 60 万 / 数字 70 万美元］；
     - **Lot 2**：$\ge \text{USD } 300,000$（大写与数字一致，30 万美元）；
     - **两标段同投**：原文为 `nine hundred thousand United States Dollars (USD 1,000,000)`［大写 90 万 / 数字 100 万美元］；联营体牵头方 $\ge 50\%$，其他成员各 $\ge 30\%$。
  4. **通用工程合同业绩（Section IV Table 3.1，2021 年 1 月至今实质完工的取水/水厂/泵站/过滤站/配水节点工程，含 2 处不一致）**：
     - 至少 **2 个**实质完工合同：
     - **Lot 1**：原文为每个合同额 $\ge \text{USD } 2,400,000$ `(two million United States Dollars)`［数字 240 万 / 大写 200 万美元］；
     - **Lot 2**：原文为每个合同额 $\ge \text{USD } 1,200,000$ `(one million United States Dollars)`［数字 120 万 / 大写 100 万美元］；
     - 两标段同投按累计且同一合同不可重复计算；联营体牵头方须至少满足其中 1 个合同。
- **专项施工与设计业绩及本地资质豁免（Section IV Table 3.2 & Data Sheet ITP 10.5）**：
  - **Lot 1（2021 年 1 月至今）**：① 钻探并安装深井潜水泵的生产水井（井深 $\ge 70\text{ m}$）不少于 **10 口**；② 现浇钢筋混凝土饮用水蓄水池不少于 **1 座**（容积 $\ge 500\text{ m}^3$）；③ 至少 **1 项**供水设施（水井/泵站/蓄水池）详细设计通过乌兹别克斯坦国家专家审查（State Expertise）或项目所在国同等主管部门审批。
  - **Lot 2（2021 年 1 月至今）**：① 井深 $\ge 70\text{ m}$ 生产水井及潜水泵安装不少于 **3 口**；② 现浇钢筋混凝土饮用水蓄水池不少于 **1 座**（容积 $\ge 1,000\text{ m}^3$）；③ 至少 **1 项**供水设施详细设计通过主管部门审批。
  - **两标段同投累计**：13 口深井（$\ge 70\text{ m}$）+ 2 座现浇蓄水池（$\ge 1,000\text{ m}^3$ 与 $\ge 500\text{ m}^3$ 各 1 座）+ 1 项获批详细设计（该项设计经验允许由投标人提名的设计分包商满足，填报 `Form SUB-3`）。
  - **乌国设计资质与钻井许可豁免条款（Data Sheet ITP 10.5）**：外国投标人在投标时**无需持有**乌国设计牌照或地下水钻井许可，标书允许任选其一：① 在标书中提名一家持有乌国有效设计/钻井牌照的分包商；或 ② 出具书面承诺函，承诺在收到中标通知书（Letter of Acceptance）后 **42 个日历日内**办妥相关许可。
  - **免税政策（Data Sheet ITP 12.1）**：根据乌兹别克斯坦税法第 243 条第 23 款及海关法第 297 条，本项目免征增值税（VAT）与进口关税，报价统一报不含 VAT 与关税的美元固定总价。

---

### 2. 阿尔巴尼亚·都拉斯 Fushe Kuqe 输水干管及新建供水泵站工程（AFD 贷款 · 0元购标 · ⚠️ 查出重大强制踏勘排他条款）
- **项目编号与名称**：AFD dgMarket Notice ID `116465359` — *REHABILITATION OF FUSHE KUQE WATER SUPPLY TRANSMISSION MAIN AND CONSTRUCTION OF A NEW WATER SUPPLY PUMPING STATION IN FUSHE KUQE, DURRES*
- **业主 / 资金来源**：阿尔巴尼亚国家供水排水局（AKUK，邮箱 `procurement_afd_durres@akuk.gov.al`） / 法国开发署（AFD）
- **工程核心范围**：进场道路与新建桥梁、新建 $3,000\text{ m}^3$ 中间蓄水池、新建主供水泵站及电气控制楼、新建 DN600 球墨铸铁（DCI）输水干管、加氯消毒及流量计量系统。
- **最终截止时间**：**2026 年 12 月 14 日 12:00（地拉那当地时间）**，**仅限纸质现场递交**（1 正 + 2 副 + 1 电子 U 盘/光盘，递交至地拉那 AKUK 总部三楼 `Rruga Sami Frasheri Nr. 4, Tirane`）。
- **投标保证金（Section II BDS ITB 19.1）**：**EUR 600,000（60 万欧元）**，须由阿尔巴尼亚央行批准的阿国境内银行出具，或由境外银行出具并经阿国境内银行保兑（Confirmed）。
- **⚠️ 【重大排他风险预警（主标书第 25 页 BDS ITB 7.4 及 11月11日第 1 号澄清补遗）】**：
  - 主标书第 25 页 `ITB 7.4` 明文规定：**2026 年 11 月 16 日 10:00** 在 Fushekuqe 泵站举行的标前会与现场踏勘为**强制必到项，未参加将直接被废标排除**（原文：*"Pre-bid visit and meeting participation mandatory is OBLIGATORY and reason for exclusion in case of not participation"*）。
  - 11 月 11 日发布的《Clarification & Modification No. 1》第 1、3 问进一步确认：踏勘结束时签发《标前到场证明（Certificate of pre-bid presence）》，且业主明确拒绝了外国投标人因签证周期申请推迟踏勘的请求（原文：*"No. The pre-bid meeting can not be rescheduled."*）。
  - **结论与应对建议**：任何未在 11 月 16 日到场领取踏勘证明的企业**已无法作为独立投标人（Single Entity）直投**。若与已拿踏勘证明的企业组建联营体（ITB 4.1 限制 JV 最多 2 名成员）是否可豁免另一方踏勘证明，标书未明示（须向 AKUK 书面澄清确认）；因此最稳妥的切入方式是**不耗费资源准备独立总包投标，仅考虑作为 DN600 球墨铸铁管材与大型水泵机电设备的分包供货商（Sub-Supplier）向参标总包供货**。
- **资格硬门槛（Section III Pages 38–42，供参考）**：
  1. **财务门槛（3.1 & 3.2）**：近 5 年年均营业额 $\ge \text{EUR } 20,000,000$（2,000 万欧元，JV 牵头方 $\ge 50\%$ 即 1,000 万欧元）；专项可用流动资金/授信 $\ge \text{EUR } 2,000,000$（200 万欧元）；2023–2025 近 3 年满足平均 EBITDA > 0、净资产 > 0、平均流动比率 > 1、平均负债/EBITDA < 6 四项中之二。
  2. **业绩门槛（4.1 & 4.2，2016 年 1 月 1 日至截标日）**：① 2016 年 1 月 1 日以来具备 FIDIC 框架施工合同经验；② 至少完成 **3 个** FIDIC 供水工程合同，每个合同额 $\ge \text{EUR } 8,000,000$（800 万欧元）；③ 专项业绩包含：长度 $\ge 3.0\text{ km}$ 且管径 $\ge \text{DN}500$ 的球墨铸铁（DCI）供水管线（最多 2 个合同累计）、容积 $\ge 2,000\text{ m}^3$ 的钢筋混凝土蓄水池、以及 **2 个**装机流量 $>300\text{ L/s}$ 且总扬程 $>200\text{ m}$ 的新建供水泵站。
  3. **体系与税务**：ISO 9001 / 14001 / 45001（JV 每方均须具备）；本项目**不免征增值税**（ITB 14.7：*The VAT is not exempted*，报价单列 VAT）。

---

### 3. 乌兹别克斯坦·布哈拉市 6 条主干道供水管网工程（BWSP-W/RFB/11 · AIIB 亚投行贷款 · 需 $150 购标费）
- **项目编号与名称**：AIIB Loan No. `L0314A` / Tender No. `BWSP-W/RFB/11` — *Construction Works for Water Supply system in 6 main streets of Bukhara city, Bukhara Region*
- **业主 / 联系方式**：`AIIB PCU under JSC Uzsuvtaminot`（主任 Mr. Shuxrat Ziyakulovich Djurayev，地址：塔什干市 Yunusabad 区 Bogishamol 街 159A 号 2 楼 214 室，电话 `+99855 503-12-55 ext.280`，邮箱 `procurement.aiib@uzsuv.uz`，抄送 `po.aiib@uzsuv.uz`）
- **工程范围与工期**：布哈拉市 6 条主干道（A. Navoi 街 3.2 km、Gazli Shoh 街 2.8 km、B. Nakshband 街 1.6 km、Gijduvon 街 1.5 km、I. Karimov 街 4.2 km、Ibn Sino 街 2.1 km）DN150～DN1000 供水干管施工，总长 **15.4 km**，工期 **6 个月**。
- **最终截止时间**：**2026 年 12 月 14 日 16:00（塔什干时间）**，**仅限纸质现场递交**（*Electronic tendering will not be permitted*），同日 16:05 现场公开开标。
- **投标保证金**：**USD 45,000（4.5 万美元）**。
- **购标方式与金额说明（按贵司指示，我方仅列出官方路径与金额，暂不代购或安排付费）**：
  - **购标金额**：**USD 150（150 美元不可退购标费）**，或按付款当日乌央行汇率折算的乌兹别克苏姆（UZS）；如需业主通过国际空运寄送纸质标书需另付 USD 300（若贵司决定购标，可在发函申购时先向业主邮箱询问汇付 USD 150 后能否直接通过邮件发送电子版全套标书及资格标准 Section III）。
  - **官方美元收款账户（逐字核对自 SPN 原件第 7 条；汇款前请务必先发邮件至 `procurement.aiib@uzsuv.uz` 及 `po.aiib@uzsuv.uz` 与 PCU 二次确认收款账户信息）**：
    - **Account Name**: `“Asian Infrastructure Investment Bank Projects Coordination Unit”`
    - **Account No (USD)**: `2021 0840 0052 7612 4005`（苏姆 UZS 账号：`2021 0000 7052 7612 4004`）
    - **Bank Name**: `Join-Stock [sic] Commercial Bank «UZPROMSTROYBANK»`（Bank Code: `00440` / SWIFT: `UJSIUZ22` / TIN: `307680993`）
    - **Correspondent Bank (USD)**: `JP MORGAN CHASE BANK, NEW YORK, USA`（Account No: `400 – 000261` / SWIFT: `CHASUS33`）

---

## 二、我方在重点项目上可提供的合作配合与支持说明

1. **乌兹别克斯坦（苏尔汉河 SWP-3 & 布哈拉 RFB/11）**：
   - **当地设计院与深井钻探分包商寻源接洽**：针对 SWP-3 要求的“乌兹国家专家审查（State Expertise）设计经验、乌国设计资质及 $\ge 70\text{ m}$ 深井钻探许可”，我方可根据标书 `ITP 10.5` 及 `Table 3.2(c)` 允许提名分包商的规则，协助在乌兹别克斯坦当地寻源、筛选并接洽持证市政给排水设计机构与深井钻探施工分包商。
   - **机电泵阀管材成套集拼与出口单证配合**：可配合贵司完成深井潜水泵、变频控制柜、箱变、球墨铸铁管/PE 管材、阀门及流量计的国内合作制造厂询价锁价、原厂授权（MAF）组织，并配合准备乌国 EBRD/AIIB 国际贷款项目免税清关所需的出口报关及检验单证（SGS/BV 装船前验货）。
   - **现场踏勘与纸质投递协助**：SWP-3 全程电子投递且踏勘非强制；若贵司后续决定派员赴苏尔汉河现场踏勘或申购布哈拉 RFB/11 递交纸质标书，我方可协助寻找联系塔什干当地俄/乌语翻译、商务向导及印务跑腿服务。
2. **阿尔巴尼亚（都拉斯 Fushe Kuqe）**：
   - 鉴于该项目 11 月 16 日强制踏勘已结束、独立直投不可行，若贵司希望以 **DN600 球墨铸铁管材或 $>300\text{ L/s}$ 高扬程主泵站设备供货商**身份参与，我方可协助检索并尝试联系已参加 11 月 16 日标前会的参标总包商，配合推送管材与机电成套供货方案。
